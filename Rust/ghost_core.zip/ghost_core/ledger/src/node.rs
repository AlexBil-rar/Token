// ledger/src/node.rs

use std::time::{SystemTime, UNIX_EPOCH};
use std::collections::HashMap;
use crate::dag::DAG;
use crate::mempool::Mempool;
use crate::state::LedgerState;
use crate::transaction::TransactionVertex;
use crate::validator::{ValidationResult, Validator};
use crate::pruner::Pruner;
use crate::anti_spam::{AntiSpamController, RateLimitResult};
use crate::merkle::{MerkleTree, StateCheckpoint};
use crate::checkpoint::{CheckpointVertex, CheckpointRegistry};
use crate::privacy::{DecoyPool, DiffusionConfig, ParentSelectionConfig, select_parents_with_privacy};

const RESOLVE_MIN_WEIGHT: u64 = 3;

#[derive(Debug, Default)]
pub struct ConflictResolverState {
    pub conflict_sets: std::collections::HashMap<(String, u64), Vec<String>>,
    pub resolved: std::collections::HashMap<(String, u64), String>,
}

impl ConflictResolverState {
    pub fn new() -> Self { Self::default() }

    pub fn register(&mut self, sender: &str, nonce: u64, tx_id: &str) {
        self.conflict_sets
            .entry((sender.to_string(), nonce))
            .or_default()
            .push(tx_id.to_string());
    }

    pub fn resolve_ready(
        &mut self,
        dag: &mut crate::dag::DAG,
        stake_weights: &HashMap<String, f64>,
        total_stake: f64,
    ) -> Vec<(String, String)> {
        let ready: Vec<(String, u64)> = self.conflict_sets.iter()
            .filter(|(key, ids)| {
                !self.resolved.contains_key(*key) && ids.len() > 1 &&
                ids.iter().all(|id| {
                    dag.get_transaction(id)
                        .map(|t| t.weight >= RESOLVE_MIN_WEIGHT)
                        .unwrap_or(false)
                })
            })
            .map(|(k, _)| k.clone())
            .collect();

        let mut losers = Vec::new();

        for key in ready {
            let ids = match self.conflict_sets.get(&key) { Some(v) => v.clone(), None => continue };

            let scores: Vec<(String, f64)> = ids.iter().filter_map(|id| {
                let tx = dag.get_transaction(id)?;
                let stake = stake_weights.get(&tx.sender).copied().unwrap_or(0.0);
                let ratio = if total_stake > 0.0 { (stake / total_stake).clamp(0.0, 1.0) } else { 0.0 };
                let multiplier = 1.0 + ratio * 2.0;
                Some((id.clone(), tx.weight as f64 * multiplier))
            }).collect();

            if scores.is_empty() { continue; }

            let winner = scores.iter()
                .max_by(|(id_a, sa), (id_b, sb)| {
                    sa.partial_cmp(sb).unwrap_or(std::cmp::Ordering::Equal)
                        .then_with(|| id_b.cmp(id_a))
                })
                .map(|(id, _)| id.clone());

            if let Some(winner_id) = winner {
                for id in &ids {
                    if id != &winner_id {
                        if let Some(t) = dag.get_transaction_mut(id) {
                            t.status = crate::transaction::TxStatus::Conflict;
                            losers.push((id.clone(), t.sender.clone()));
                        }
                    }
                }
                self.resolved.insert(key, winner_id);
            }
        }

        losers
    }
}

pub struct WalletInfo {
    pub address: String,
    pub public_key: String,
    pub private_key_hex: String,
}

#[derive(Debug, PartialEq)]
pub enum StakeResult {
    Registered { amount: u64 },
    InsufficientBalance,
    BelowMinimum { min: u64 },
    AlreadyStaking,
}

#[derive(Debug, Clone)]
pub struct NodeStake {
    pub address: String,
    pub amount: u64,
    pub active: bool,
    pub violations: u32,
}

impl NodeStake {
    pub fn new(address: String, amount: u64) -> Self {
        NodeStake { address, amount, active: true, violations: 0 }
    }

    pub const MIN_STAKE: u64 = 1_000;

    pub fn is_validator(&self) -> bool {
        self.active && self.amount >= Self::MIN_STAKE
    }
}

pub struct Node {
    pub dag: DAG,
    pub state: LedgerState,
    pub mempool: Mempool,
    pub validator: Validator,
    pub pruner: Pruner,
    pub anti_spam: AntiSpamController,
    pub stakes: HashMap<String, NodeStake>,
    pub network_start: f64,
    pub last_state_root: Option<String>,
    pub checkpoint_height: u64,
    pub checkpoint_registry: CheckpointRegistry,
    pub conflict_resolver: ConflictResolverState,
    pub decoy_pool: DecoyPool,
    pub diffusion: DiffusionConfig,
}

impl Node {
    pub fn new() -> Self {
        Node {
            dag: DAG::new(),
            state: LedgerState::new(),
            mempool: Mempool::new(),
            validator: Validator::new(),
            pruner: Pruner::default(),
            anti_spam: AntiSpamController::new(),
            stakes: HashMap::new(),
            network_start: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs_f64(),
            last_state_root: None,
            checkpoint_height: 0,
            checkpoint_registry: CheckpointRegistry::new(),
            conflict_resolver: ConflictResolverState::new(),
            decoy_pool: DecoyPool::new(50),
            diffusion: DiffusionConfig::default(),
        }
    }

    pub fn bootstrap_genesis(&mut self, address: &str, balance: u64) {
        self.state.credit(address, balance);
        self.update_state_root();
    }

    pub fn faucet(&mut self, address: &str, amount: u64) {
        self.state.credit(address, amount);
    }

    pub fn select_parents(&self) -> Vec<String> {
        let tips = self.dag.get_tips();
        if tips.is_empty() { return vec![]; }
        tips.into_iter().take(2).collect()
    }

    pub fn select_parents_private(&mut self) -> Vec<String> {
        let tips = self.dag.get_tips();
        if tips.is_empty() { return vec![]; }
        let config = ParentSelectionConfig::default();
        select_parents_with_privacy(&tips, &mut self.decoy_pool, &config, 2)
    }

    pub fn current_difficulty(&self) -> usize {
        self.anti_spam.current_difficulty()
    }

    pub fn mine_anti_spam(&self, tx: &mut TransactionVertex) {
        let difficulty = self.anti_spam.current_difficulty();
        tx.mine_anti_spam(difficulty);
    }

    pub fn register_stake(&mut self, address: &str, amount: u64) -> StakeResult {
        if amount < NodeStake::MIN_STAKE {
            return StakeResult::BelowMinimum { min: NodeStake::MIN_STAKE };
        }

        if let Some(existing) = self.stakes.get(address) {
            if existing.active {
                return StakeResult::AlreadyStaking;
            }
        }

        let balance = self.state.get_balance(address);
        if balance < amount {
            return StakeResult::InsufficientBalance;
        }

        if let Some(b) = self.state.balances.get_mut(address) {
            *b = b.saturating_sub(amount);
        }

        self.stakes.insert(address.to_string(), NodeStake::new(address.to_string(), amount));
        StakeResult::Registered { amount }
    }

    pub fn total_stake(&self) -> f64 {
        self.stakes.values()
            .filter(|s| s.is_validator())
            .map(|s| s.amount as f64)
            .sum()
    }

    pub fn stake_of(&self, address: &str) -> f64 {
        self.stakes.get(address)
            .filter(|s| s.is_validator())
            .map(|s| s.amount as f64)
            .unwrap_or(0.0)
    }

    pub fn stake_weights(&self) -> HashMap<String, f64> {
        self.stakes.values()
            .filter(|s| s.is_validator())
            .map(|s| (s.address.clone(), s.amount as f64))
            .collect()
    }

    pub fn is_validator(&self, address: &str) -> bool {
        self.stakes.get(address)
            .map(|s| s.is_validator())
            .unwrap_or(false)
    }

    pub fn update_state_root(&mut self) {
        let state_map: HashMap<String, (u64, u64)> = self.state.balances
            .iter()
            .map(|(addr, bal)| {
                let nonce = self.state.nonces.get(addr).copied().unwrap_or(0);
                (addr.clone(), (*bal, nonce))
            })
            .collect();

        let tree = MerkleTree::from_state(&state_map);
        self.last_state_root = Some(tree.root);
    }

    pub fn create_checkpoint(&mut self) -> StateCheckpoint {
        self.update_state_root();
        self.checkpoint_height += 1;

        StateCheckpoint::new(
            self.last_state_root.clone().unwrap_or_default(),
            self.checkpoint_height,
            self.state.balances.len(),
        )
    }

    pub fn maybe_create_dag_checkpoint(&mut self) -> Option<String> {
        let dag_height = self.dag.vertices.len() as u64;
        if !self.checkpoint_registry.should_checkpoint(dag_height) {
            return None;
        }

        self.update_state_root();
        let state_root = self.last_state_root.clone()?;
        let sequence = self.checkpoint_registry.len() as u64 + 1;
        let parents = self.select_parents();

        let cp = CheckpointVertex::new(
            state_root.clone(),
            sequence,
            dag_height,
            self.state.balances.len(),
            "node".to_string(),
            parents,
        );

        let cp_id = cp.checkpoint_id.clone();
        self.checkpoint_registry.register(cp);
        Some(cp_id)
    }

    pub fn latest_trusted_checkpoint(&self) -> Option<&CheckpointVertex> {
        self.checkpoint_registry.latest_finalized()
    }

    pub fn relay_delay(&self, tx_id: &str) -> std::time::Duration {
        self.diffusion.relay_delay(tx_id)
    }

    pub fn verify_state_root(&self, expected_root: &str) -> Result<(), String> {
        let state_map: HashMap<String, (u64, u64)> = self.state.balances
            .iter()
            .map(|(addr, bal)| {
                let nonce = self.state.nonces.get(addr).copied().unwrap_or(0);
                (addr.clone(), (*bal, nonce))
            })
            .collect();

        MerkleTree::verify(&state_map, expected_root)
    }

    pub fn create_transaction(
        &mut self,
        wallet: &WalletInfo,
        receiver: &str,
        amount: u64,
        sign_fn: impl Fn(&[u8]) -> String,
    ) -> TransactionVertex {
        let nonce = self.state.get_nonce(&wallet.address) + 1;
        let parents = self.select_parents_private();
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();

        let mut tx = TransactionVertex::new(
            wallet.address.clone(),
            receiver.to_string(),
            amount,
            nonce,
            timestamp,
            wallet.public_key.clone(),
            parents,
        );

        self.mine_anti_spam(&mut tx);
        tx.signature = sign_fn(&tx.signing_payload());
        tx.finalize();
        tx
    }

    pub fn submit_transaction(&mut self, tx: TransactionVertex) -> ValidationResult {
        match self.anti_spam.check_and_record_address(&tx.sender) {
            RateLimitResult::Rejected { reason } => {
                return ValidationResult::err("rate_limited", &reason);
            }
            RateLimitResult::Allowed(_priority) => {
            }
        }

        let difficulty = self.anti_spam.current_difficulty();

        let result = self.validator.validate_full_with_difficulty(
            &tx, &self.dag, &mut self.state, difficulty,
        );
        if !result.ok {
            return result;
        }

        if self.mempool.has(&tx.tx_id) {
            return ValidationResult::err("duplicate_mempool", "transaction already in mempool");
        }

        let tx_id = tx.tx_id.clone();
        self.mempool.add(tx.clone());

        if self.state.apply_transaction(&tx).is_err() {
            self.mempool.remove(&tx_id);
            return ValidationResult::err("state_error", "failed to apply transaction");
        }

        if self.dag.add_transaction(tx).is_err() {
            self.mempool.remove(&tx_id);
            return ValidationResult::err("dag_error", "failed to add to DAG");
        }

        self.dag.propagate_weight(&tx_id);
        self.mempool.remove(&tx_id);
        self.anti_spam.record_transaction();
        self.decoy_pool.record(tx_id.clone());

        {
            let sender = self.dag.get_transaction(&tx_id)
                .map(|t| (t.sender.clone(), t.nonce))
                .unwrap_or_default();
            if !sender.0.is_empty() {
                self.conflict_resolver.register(&sender.0, sender.1, &tx_id);
            }
            let stake_weights = self.stake_weights();
            let total_stake = self.total_stake();
            let _losers = self.conflict_resolver.resolve_ready(
                &mut self.dag, &stake_weights, total_stake,
            );
        }

        let total = self.dag.vertices.len() as u64;
        if total % 100 == 0 {
            self.update_state_root();
        }

        if let Some(cp_id) = self.maybe_create_dag_checkpoint() {
            let _ = cp_id; 
        }

        if self.pruner.should_prune_default(&self.dag) {
            let result = self.pruner.prune(&mut self.dag, &self.state);
            if result.pruned_count > 0 {
                self.update_state_root();
            }
        }

        ValidationResult::ok("accepted", "transaction accepted")
    }

    pub fn get_balance(&mut self, address: &str) -> u64 {
        self.state.get_balance(address)
    }

    pub fn get_nonce(&mut self, address: &str) -> u64 {
        self.state.get_nonce(address)
    }

    pub fn dag_stats(&self) -> crate::dag::DagStats {
        self.dag.stats()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_wallet(address: &str, public_key: &str) -> WalletInfo {
        WalletInfo {
            address: address.to_string(),
            public_key: public_key.to_string(),
            private_key_hex: String::new(),
        }
    }

    #[test]
    fn test_bootstrap_genesis() {
        let mut node = Node::new();
        node.bootstrap_genesis("genesis_addr", 10_000_000);
        assert_eq!(node.get_balance("genesis_addr"), 10_000_000);
    }

    #[test]
    fn test_bootstrap_genesis_sets_state_root() {
        let mut node = Node::new();
        node.bootstrap_genesis("genesis_addr", 10_000_000);
        assert!(node.last_state_root.is_some());
    }

    #[test]
    fn test_select_parents_empty_dag() {
        let node = Node::new();
        assert!(node.select_parents().is_empty());
    }

    #[test]
    fn test_mine_anti_spam() {
        let node = Node::new();
        let mut tx = TransactionVertex::new(
            "alice".to_string(), "bob".to_string(),
            100, 1, 1000, "pk".to_string(), vec![],
        );
        node.mine_anti_spam(&mut tx);
        let difficulty = node.current_difficulty();
        let prefix = "0".repeat(difficulty);
        assert!(tx.anti_spam_hash.starts_with(&prefix));
    }

    #[test]
    fn test_dag_stats_empty() {
        let node = Node::new();
        let stats = node.dag_stats();
        assert_eq!(stats.total_vertices, 0);
    }

    #[test]
    fn test_initial_difficulty() {
        let node = Node::new();
        assert!(node.current_difficulty() >= 2);
    }

    #[test]
    fn test_register_stake_success() {
        let mut node = Node::new();
        node.state.credit("alice", 5000);
        let result = node.register_stake("alice", 1000);
        assert_eq!(result, StakeResult::Registered { amount: 1000 });
        assert!(node.is_validator("alice"));
    }

    #[test]
    fn test_register_stake_below_minimum() {
        let mut node = Node::new();
        node.state.credit("alice", 5000);
        let result = node.register_stake("alice", 100);
        assert_eq!(result, StakeResult::BelowMinimum { min: NodeStake::MIN_STAKE });
        assert!(!node.is_validator("alice"));
    }

    #[test]
    fn test_register_stake_insufficient_balance() {
        let mut node = Node::new();
        node.state.credit("alice", 500);
        let result = node.register_stake("alice", 1000);
        assert_eq!(result, StakeResult::InsufficientBalance);
    }

    #[test]
    fn test_register_stake_deducts_balance() {
        let mut node = Node::new();
        node.state.credit("alice", 5000);
        node.register_stake("alice", 1000);
        assert_eq!(node.get_balance("alice"), 4000);
    }

    #[test]
    fn test_register_stake_already_staking() {
        let mut node = Node::new();
        node.state.credit("alice", 5000);
        node.register_stake("alice", 1000);
        let result = node.register_stake("alice", 1000);
        assert_eq!(result, StakeResult::AlreadyStaking);
    }

    #[test]
    fn test_total_stake_sums_validators() {
        let mut node = Node::new();
        node.state.credit("alice", 5000);
        node.state.credit("bob", 5000);
        node.register_stake("alice", 2000);
        node.register_stake("bob", 3000);
        assert_eq!(node.total_stake(), 5000.0);
    }

    #[test]
    fn test_stake_of_non_validator_is_zero() {
        let node = Node::new();
        assert_eq!(node.stake_of("nobody"), 0.0);
    }

    #[test]
    fn test_stake_weights_includes_validators() {
        let mut node = Node::new();
        node.state.credit("alice", 5000);
        node.register_stake("alice", 2000);
        let weights = node.stake_weights();
        assert!(weights.contains_key("alice"));
        assert_eq!(weights["alice"], 2000.0);
    }

    #[test]
    fn test_no_stake_not_in_weights() {
        let mut node = Node::new();
        node.state.credit("alice", 5000);
        let weights = node.stake_weights();
        assert!(!weights.contains_key("alice"));
    }


    #[test]
    fn test_update_state_root_after_genesis() {
        let mut node = Node::new();
        node.bootstrap_genesis("alice", 1000);
        let root1 = node.last_state_root.clone().unwrap();

        node.state.credit("bob", 500);
        node.update_state_root();
        let root2 = node.last_state_root.clone().unwrap();

        assert_ne!(root1, root2);
    }

    #[test]
    fn test_verify_state_root_correct() {
        let mut node = Node::new();
        node.bootstrap_genesis("alice", 1000);
        let root = node.last_state_root.clone().unwrap();
        assert!(node.verify_state_root(&root).is_ok());
    }

    #[test]
    fn test_verify_state_root_wrong_fails() {
        let mut node = Node::new();
        node.bootstrap_genesis("alice", 1000);
        assert!(node.verify_state_root("wrong_root").is_err());
    }

    #[test]
    fn test_create_checkpoint() {
        let mut node = Node::new();
        node.bootstrap_genesis("alice", 1000);
        let cp = node.create_checkpoint();
        assert!(!cp.state_root.is_empty());
        assert_eq!(cp.dag_height, 1);
        assert_eq!(cp.address_count, 1);
    }

    #[test]
    fn test_checkpoint_height_increments() {
        let mut node = Node::new();
        node.bootstrap_genesis("alice", 1000);
        let cp1 = node.create_checkpoint();
        let cp2 = node.create_checkpoint();
        assert_eq!(cp1.dag_height, 1);
        assert_eq!(cp2.dag_height, 2);
    }

    #[test]
    fn test_select_parents_private_empty_dag() {
        let mut node = Node::new();
        assert!(node.select_parents_private().is_empty());
    }

    #[test]
    fn test_select_parents_private_with_tips() {
        let mut node = Node::new();
        node.bootstrap_genesis("alice", 10_000);
        use crate::transaction::TransactionVertex;
        for i in 1..=5u64 {
            let mut tx = TransactionVertex::new(
                "alice".to_string(), "bob".to_string(),
                10, i, 1000, "pk".to_string(), vec![],
            );
            tx.tx_id = format!("tx_{}", i);
            node.dag.add_transaction(tx).unwrap();
        }
        let parents = node.select_parents_private();
        assert!(!parents.is_empty());
        assert!(parents.len() <= 2);
    }

    #[test]
    fn test_decoy_pool_grows_with_transactions() {
        let node = Node::new();
        assert_eq!(node.decoy_pool.size(), 0);
    }

    #[test]
    fn test_relay_delay_in_range() {
        let node = Node::new();
        let delay = node.relay_delay("tx_test_abc");
        assert!(delay.as_millis() >= 50);
        assert!(delay.as_millis() <= 500);
    }

    #[test]
    fn test_relay_delay_deterministic() {
        let node = Node::new();
        let d1 = node.relay_delay("tx_same_id");
        let d2 = node.relay_delay("tx_same_id");
        assert_eq!(d1, d2);
    }

    #[test]
    fn test_relay_delay_different_for_different_txs() {
        let node = Node::new();
        let d1 = node.relay_delay("tx_aaaaaa");
        let d2 = node.relay_delay("tx_zzzzzz");
        assert!(d1.as_millis() >= 50 && d1.as_millis() <= 500);
        assert!(d2.as_millis() >= 50 && d2.as_millis() <= 500);
    }

    #[test]
    fn test_no_relay_delay_when_disabled() {
        let mut node = Node::new();
        node.diffusion = crate::privacy::DiffusionConfig::disabled();
        let delay = node.relay_delay("any_tx_id");
        assert_eq!(delay, std::time::Duration::ZERO);
    }
}